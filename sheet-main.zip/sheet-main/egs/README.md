# egs (examples, or recipes)

- **Sep 2025**: There used to be a complete usage guide here, but it had been moved to the [documentation website](https://unilight.github.io/sheet/).