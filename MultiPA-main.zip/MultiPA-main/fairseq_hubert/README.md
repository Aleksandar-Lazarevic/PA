
Download HuBERT Base (~95M params) from https://github.com/facebookresearch/fairseq/blob/main/examples/hubert/README.md

Put the hubert_base_ls960.pt model here.