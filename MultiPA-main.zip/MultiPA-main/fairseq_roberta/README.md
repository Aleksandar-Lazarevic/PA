
Download roberta.base model from https://github.com/facebookresearch/fairseq/blob/main/examples/roberta/README.md

Put the model.pt and dict.txt here